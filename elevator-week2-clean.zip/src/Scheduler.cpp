#include "Scheduler.hpp"
#include <algorithm>
#include <limits>

// ======================= Master Controller Implementation =======================

MasterController::MasterController(Building& building, EventQueue<Event>& queue)
    : building_(building), eventQueue_(queue) {}

void MasterController::handleHallCall(int floor, Direction dir) {
    std::lock_guard<std::mutex> lock(mutex_);
    
    auto key = std::make_pair(floor, dir);
    
    // Check if already assigned (prevent duplicate assignment)
    if (assignments_.find(key) != assignments_.end()) {
        return;
    }
    
    // Register hall call in building
    building_.registerHallCall(floor, dir);
    
    // Select best elevator using LOOK algorithm cost function
    int elevatorId = selectElevator(floor, dir);
    
    if (elevatorId >= 0) {
        // Store assignment
        assignments_[key] = elevatorId;
        
        // Dispatch the elevator if it's idle
        dispatchElevator(elevatorId);
    }
}

void MasterController::handleCarCall(int elevatorId, int floor) {
    if (!building_.isValidElevator(elevatorId) || !building_.isValidFloor(floor)) {
        return;
    }
    
    // Add to elevator's car calls
    building_.getElevator(elevatorId).addCarCall(floor);
    
    // Dispatch if idle
    dispatchElevator(elevatorId);
}

void MasterController::onElevatorArrived(int elevatorId, int floor) {
    Elevator& elev = building_.getElevator(elevatorId);
    Direction dir = elev.getDirection();
    
    // Check if this elevator was assigned to serve hall call here
    {
        std::lock_guard<std::mutex> lock(mutex_);
        auto key = std::make_pair(floor, dir);
        auto it = assignments_.find(key);
        if (it != assignments_.end() && it->second == elevatorId) {
            // Clear assignment and hall call
            assignments_.erase(it);
            building_.clearHallCall(floor, dir);
        }
        
        // Also check opposite direction (elevator might serve both)
        Direction opposite = (dir == Direction::Up) ? Direction::Down : Direction::Up;
        auto keyOpp = std::make_pair(floor, opposite);
        auto itOpp = assignments_.find(keyOpp);
        if (itOpp != assignments_.end() && itOpp->second == elevatorId) {
            assignments_.erase(itOpp);
            building_.clearHallCall(floor, opposite);
        }
    }
    
    // Clear car call at this floor
    elev.removeCarCall(floor);
}

void MasterController::onDoorsOpened(int elevatorId, int floor) {
    // Passengers board/alight - could add more logic here
    (void)elevatorId;
    (void)floor;
}

void MasterController::onDoorsClosed(int elevatorId) {
    // Dispatch to next destination
    dispatchElevator(elevatorId);
}

void MasterController::tick() {
    // Check idle elevators and dispatch if they have pending work
    for (int i = 0; i < building_.getNumElevators(); ++i) {
        Elevator& elev = building_.getElevator(i);
        if (elev.getState() == ElevatorState::Idle) {
            dispatchElevator(i);
        }
    }
}

// ---- Private Methods ----

int MasterController::selectElevator(int floor, Direction dir) {
    int bestElevator = -1;
    int bestCost = std::numeric_limits<int>::max();
    
    for (int i = 0; i < building_.getNumElevators(); ++i) {
        const Elevator& elev = building_.getElevator(i);
        int cost = calculateCost(elev, floor, dir);
        
        if (cost < bestCost) {
            bestCost = cost;
            bestElevator = i;
        }
    }
    
    return bestElevator;
}

int MasterController::calculateCost(const Elevator& elev, int floor, Direction dir) {
    return elev.costToServe(floor, dir, building_.getNumFloors());
}

void MasterController::dispatchElevator(int elevatorId) {
    Elevator& elev = building_.getElevator(elevatorId);
    
    // Only dispatch if idle
    if (elev.getState() != ElevatorState::Idle) {
        return;
    }
    
    // Gather all destinations
    std::set<int> destinations = getAllDestinations(elevatorId);
    
    if (destinations.empty()) {
        return;  // Nothing to do
    }
    
    // Find closest destination
    int current = elev.getCurrentFloor();
    auto closest = std::min_element(destinations.begin(), destinations.end(),
        [current](int a, int b) {
            return std::abs(a - current) < std::abs(b - current);
        });
    
    int target = *closest;
    
    if (target == current) {
        // Already at destination, open doors
        elev.openDoors(building_.getConfig().doorOpenTicks);
        
        // Generate arrived event
        Event event;
        event.type = EventType::ElevatorArrived;
        event.elevatorId = elevatorId;
        event.floor = current;
        eventQueue_.push(event);
    } else {
        // Start moving toward target
        Direction dir = (target > current) ? Direction::Up : Direction::Down;
        elev.startMoving(dir, building_.getConfig().floorTravelTicks);
    }
}

bool MasterController::shouldStopAtFloor(int elevatorId, int floor) {
    const Elevator& elev = building_.getElevator(elevatorId);
    
    // Stop for car call
    if (elev.hasCarCallAt(floor)) {
        return true;
    }
    
    // Stop for hall call assignment
    Direction dir = elev.getDirection();
    if (auto assigned = getAssignment(floor, dir); assigned && *assigned == elevatorId) {
        return true;
    }
    
    return false;
}

std::optional<int> MasterController::getAssignment(int floor, Direction dir) {
    std::lock_guard<std::mutex> lock(mutex_);
    auto key = std::make_pair(floor, dir);
    auto it = assignments_.find(key);
    if (it != assignments_.end()) {
        return it->second;
    }
    return std::nullopt;
}

void MasterController::clearAssignment(int floor, Direction dir) {
    std::lock_guard<std::mutex> lock(mutex_);
    assignments_.erase(std::make_pair(floor, dir));
}

std::set<int> MasterController::getAllDestinations(int elevatorId) {
    std::set<int> destinations = building_.getElevator(elevatorId).getCarCalls();
    
    // Add assigned hall call floors
    {
        std::lock_guard<std::mutex> lock(mutex_);
        for (const auto& [key, assignedId] : assignments_) {
            if (assignedId == elevatorId) {
                destinations.insert(key.first);
            }
        }
    }
    
    return destinations;
}

// ---- Testing/Debug Access ----

size_t MasterController::getAssignmentCount() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return assignments_.size();
}

bool MasterController::hasAssignment(int floor, Direction dir) const {
    std::lock_guard<std::mutex> lock(mutex_);
    return assignments_.find(std::make_pair(floor, dir)) != assignments_.end();
}

std::optional<int> MasterController::getAssignedElevator(int floor, Direction dir) const {
    std::lock_guard<std::mutex> lock(mutex_);
    auto it = assignments_.find(std::make_pair(floor, dir));
    if (it != assignments_.end()) {
        return it->second;
    }
    return std::nullopt;
}

// ======================= Factory Function =======================

std::unique_ptr<IScheduler> createScheduler(
    Building& building,
    EventQueue<Event>& queue
) {
    return std::make_unique<MasterController>(building, queue);
}
