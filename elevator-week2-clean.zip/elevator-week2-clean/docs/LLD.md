# Elevator Simulation - Low Level Design
## Week 2: Master Controller Implementation

---

## 1. File Structure

```
elevator-sim/
├── CMakeLists.txt
├── README.md
├── docs/
│   ├── HLD.md
│   └── LLD.md
├── include/
│   ├── Types.hpp           # Enums, Config, Event
│   ├── EventQueue.hpp      # Thread-safe queue
│   ├── Domain.hpp          # Elevator, Floor, Building
│   ├── Scheduler.hpp       # IScheduler + MasterController
│   └── Simulation.hpp      # Engine, Logger, CLI
├── src/
│   ├── main.cpp            # Entry point
│   ├── Domain.cpp          # Domain implementations
│   ├── Scheduler.cpp       # MasterController implementation
│   └── Simulation.cpp      # Engine implementation
└── tests/
    ├── UnitTests.cpp       # Component tests
    └── StressTests.cpp     # Concurrency tests
```

---

## 2. Types.hpp - Core Definitions

### 2.1 Enums

```cpp
enum class Direction { Up, Down, Idle };

enum class ElevatorState {
    Idle,           // Stationary, no pending requests
    Moving,         // Traveling between floors
    DoorsOpening,   // Arrived, opening doors
    DoorsOpen,      // Passengers boarding/alighting
    DoorsClosing    // Preparing to move
};

enum class EventType {
    HallCall,       // Floor button pressed
    CarCall,        // Destination selected in car
    ElevatorArrived,// Elevator reached a floor
    DoorsOpened,
    DoorsClosed,
    Tick,
    Shutdown
};
```

### 2.2 Configuration

```cpp
struct Config {
    int numFloors = 10;         // 1-12
    int numElevators = 3;       // 1-3
    int carCapacity = 6;        // passengers
    int tickDurationMs = 500;   // simulation speed
    int doorOpenTicks = 3;      // time doors stay open
    int floorTravelTicks = 2;   // time to move 1 floor
};
```

### 2.3 Event Structure

```cpp
struct Event {
    EventType type;
    int floor = -1;
    int elevatorId = -1;
    Direction direction = Direction::Idle;
    std::chrono::steady_clock::time_point timestamp;
};
```

---

## 3. Domain Classes

### 3.1 Floor Class

```cpp
class Floor {
private:
    int floorNumber_;
    bool upButtonPressed_ = false;
    bool downButtonPressed_ = false;

public:
    explicit Floor(int number);
    
    void pressUpButton();
    void pressDownButton();
    void clearUpButton();
    void clearDownButton();
    
    bool isUpPressed() const;
    bool isDownPressed() const;
    int getNumber() const;
};
```

### 3.2 Elevator Class

```cpp
class Elevator {
private:
    int id_;
    int currentFloor_;
    Direction direction_ = Direction::Idle;
    ElevatorState state_ = ElevatorState::Idle;
    std::set<int> carCalls_;    // Sorted destinations
    int passengerCount_ = 0;
    int capacity_;
    int ticksRemaining_ = 0;    // For timed operations
    mutable std::mutex mutex_;

public:
    Elevator(int id, int capacity, int startFloor = 1);

    // Thread-safe getters
    int getId() const;
    int getCurrentFloor() const;
    Direction getDirection() const;
    ElevatorState getState() const;
    int getPassengerCount() const;
    std::set<int> getCarCalls() const;

    // Car call management
    void addCarCall(int floor);
    void removeCarCall(int floor);
    bool hasCarCallAt(int floor) const;
    bool hasAnyCarCalls() const;

    // State transitions
    void startMoving(Direction dir, int ticks);
    void arriveAtFloor(int floor);
    void openDoors(int ticks);
    void closeDoors(int ticks);
    void setIdle();

    // Scheduling helper
    int costToServe(int floor, Direction dir, int numFloors) const;
};
```

### 3.3 Building Class

```cpp
class Building {
private:
    std::vector<Floor> floors_;
    std::vector<std::unique_ptr<Elevator>> elevators_;
    Config config_;
    mutable std::mutex mutex_;

public:
    explicit Building(const Config& config);

    // Accessors
    int getNumFloors() const;
    int getNumElevators() const;
    Elevator& getElevator(int id);
    Floor& getFloor(int number);

    // Hall call management
    void registerHallCall(int floor, Direction dir);
    void clearHallCall(int floor, Direction dir);
    bool hasHallCall(int floor, Direction dir) const;
    std::vector<std::pair<int, Direction>> getAllHallCalls() const;

    // Validation
    bool isValidFloor(int floor) const;
    bool isValidElevator(int id) const;
};
```

---

## 4. EventQueue - Thread-Safe Queue

```cpp
template<typename T>
class EventQueue {
private:
    std::queue<T> queue_;
    mutable std::mutex mutex_;
    std::condition_variable cv_;
    std::atomic<bool> shutdown_{false};

public:
    void push(T event);              // Add event, notify waiters
    std::optional<T> pop();          // Blocking wait
    std::optional<T> tryPop();       // Non-blocking
    void shutdown();                 // Signal termination
    bool empty() const;
    size_t size() const;
};
```

**Key Points:**
- `push()` notifies via condition variable
- `pop()` blocks until event available or shutdown
- `shutdown()` unblocks all waiting threads
- Returns `std::optional` to handle empty/shutdown cases

---

## 5. Master Controller

### 5.1 Interface (for future extensibility)

```cpp
class IScheduler {
public:
    virtual ~IScheduler() = default;
    
    virtual void handleHallCall(int floor, Direction dir) = 0;
    virtual void handleCarCall(int elevatorId, int floor) = 0;
    virtual void onElevatorArrived(int elevatorId, int floor) = 0;
    virtual void onDoorsClosed(int elevatorId) = 0;
    virtual void tick() = 0;
    virtual std::string getName() const = 0;
};
```

### 5.2 MasterController Class

```cpp
class MasterController : public IScheduler {
private:
    Building& building_;
    EventQueue<Event>& eventQueue_;
    
    // Assignment tracking: (floor, direction) -> elevator_id
    std::map<std::pair<int, Direction>, int> assignments_;
    mutable std::mutex mutex_;

public:
    MasterController(Building& building, EventQueue<Event>& queue);

    // IScheduler implementation
    void handleHallCall(int floor, Direction dir) override;
    void handleCarCall(int elevatorId, int floor) override;
    void onElevatorArrived(int elevatorId, int floor) override;
    void onDoorsClosed(int elevatorId) override;
    void tick() override;
    std::string getName() const override { return "MasterController"; }

private:
    int selectElevator(int floor, Direction dir);
    int calculateCost(const Elevator& elev, int floor, Direction dir);
    void dispatchElevator(int elevatorId);
    void clearAssignment(int floor, Direction dir);
};
```

### 5.3 LOOK Algorithm Implementation

```cpp
int MasterController::selectElevator(int floor, Direction dir) {
    int bestElevator = -1;
    int bestCost = INT_MAX;
    
    for (int i = 0; i < building_.getNumElevators(); ++i) {
        const Elevator& elev = building_.getElevator(i);
        int cost = calculateCost(elev, floor, dir);
        
        if (cost < bestCost) {
            bestCost = cost;
            bestElevator = i;
        }
    }
    return bestElevator;
}

int MasterController::calculateCost(const Elevator& elev, 
                                     int floor, Direction dir) {
    int distance = std::abs(elev.getCurrentFloor() - floor);
    
    // Idle elevator: just distance
    if (elev.getState() == ElevatorState::Idle) {
        return distance;
    }
    
    // Check if request is "on the way"
    bool sameDirection = (elev.getDirection() == dir);
    bool onTheWay = 
        (elev.getDirection() == Direction::Up && floor > elev.getCurrentFloor()) ||
        (elev.getDirection() == Direction::Down && floor < elev.getCurrentFloor());
    
    if (sameDirection && onTheWay) {
        return distance;  // Best case: pick up en route
    }
    
    // Penalty for needing to reverse
    return distance + 2 * building_.getNumFloors();
}
```

### 5.4 Assignment Lifecycle

```
1. Hall call received
   └─► selectElevator() finds best elevator
       └─► assignments_[(floor, dir)] = elevatorId
           └─► dispatchElevator() starts movement

2. Elevator arrives at floor
   └─► Check if has assignment for this floor
       └─► If yes: clearAssignment(), clear hall call
           └─► Remove car call if present
               └─► Open doors

3. Doors close
   └─► dispatchElevator() for next destination
       └─► If no destinations: setIdle()
```

---

## 6. Simulation Engine

```cpp
class SimulationEngine {
private:
    Building building_;
    std::unique_ptr<IScheduler> scheduler_;
    EventQueue<Event> eventQueue_;
    Logger logger_;
    Config config_;
    
    std::vector<std::thread> threads_;
    std::atomic<bool> running_{false};
    std::atomic<int> currentTick_{0};

public:
    explicit SimulationEngine(const Config& config);
    ~SimulationEngine();

    void start();                              // Begin simulation
    void stop();                               // Graceful shutdown
    void requestHallCall(int floor, Direction dir);
    void requestCarCall(int elevatorId, int floor);
    void printStatus() const;

private:
    void runSimulationLoop();                  // Main loop thread
    void processTick();                        // Advance simulation
    void updateElevators();                    // State machine updates
    void processEvent(const Event& event);    // Handle events
};
```

### 6.1 Simulation Loop

```cpp
void SimulationEngine::runSimulationLoop() {
    while (running_.load()) {
        // 1. Wait for tick duration
        std::this_thread::sleep_for(
            std::chrono::milliseconds(config_.tickDurationMs));
        
        if (!running_.load()) break;
        
        // 2. Update all elevator states
        updateElevators();
        
        // 3. Let controller make decisions
        scheduler_->tick();
        
        // 4. Process any pending events
        while (auto event = eventQueue_.tryPop()) {
            processEvent(*event);
        }
        
        ++currentTick_;
    }
}
```

### 6.2 Elevator State Updates

```cpp
void SimulationEngine::updateElevators() {
    for (int i = 0; i < building_.getNumElevators(); ++i) {
        Elevator& elev = building_.getElevator(i);
        
        switch (elev.getState()) {
            case ElevatorState::Moving:
                elev.decrementTick();
                if (elev.getTicksRemaining() == 0) {
                    // Arrived at next floor
                    int next = (elev.getDirection() == Direction::Up) 
                        ? elev.getCurrentFloor() + 1 
                        : elev.getCurrentFloor() - 1;
                    elev.arriveAtFloor(next);
                    // Notify controller
                    pushEvent(EventType::ElevatorArrived, i, next);
                }
                break;
                
            case ElevatorState::DoorsOpen:
                elev.decrementTick();
                if (elev.getTicksRemaining() == 0) {
                    elev.closeDoors(1);
                }
                break;
                
            case ElevatorState::DoorsClosing:
                elev.decrementTick();
                if (elev.getTicksRemaining() == 0) {
                    pushEvent(EventType::DoorsClosed, i, -1);
                }
                break;
            // ... other states
        }
    }
}
```

---

## 7. Thread Safety Analysis

### 7.1 Shared Resources

| Resource | Writers | Readers | Protection |
|----------|---------|---------|------------|
| `EventQueue` | CLI, Engine | Engine | mutex + cv |
| `Building.floors_` | Controller | Controller, CLI | Building.mutex |
| `Elevator.*` | Engine | Controller, CLI | Elevator.mutex |
| `assignments_` | Controller | Controller | Controller.mutex |

### 7.2 Lock Ordering (Deadlock Prevention)

```
Always acquire in this order:
1. EventQueue.mutex
2. Building.mutex  
3. Elevator.mutex (by ascending ID)
4. MasterController.mutex
```

### 7.3 No Busy Loops

```cpp
// WRONG (busy loop):
while (queue.empty()) { }  // Burns CPU!

// CORRECT (condition variable):
std::unique_lock lock(mutex_);
cv_.wait(lock, [this] { return !queue_.empty() || shutdown_; });
```

---

## 8. Testing Strategy

### 8.1 Unit Tests

| Test Suite | Tests |
|------------|-------|
| `FloorTest` | Button press/clear, state queries |
| `ElevatorTest` | State transitions, car calls, direction logic |
| `BuildingTest` | Initialization, hall calls, validation |
| `EventQueueTest` | Push/pop, FIFO order, shutdown |
| `MasterControllerTest` | Assignment, cost calculation, no duplicates |

### 8.2 Key Test Cases

```cpp
// Test: Nearest elevator assigned
TEST(MasterControllerTest, AssignsNearestIdleElevator) {
    // Setup: Elev0 at floor 1, Elev1 at floor 5
    // Hall call at floor 4
    // Expected: Elev1 assigned (closer)
}

// Test: No duplicate assignments
TEST(MasterControllerTest, NoDuplicateAssignment) {
    // Hall call floor 5 Up
    // Same hall call again
    // Expected: Only one assignment exists
}

// Test: On-the-way preference
TEST(MasterControllerTest, PrefersOnTheWayElevator) {
    // Elev0: floor 3, moving Up
    // Elev1: floor 6, idle
    // Hall call: floor 5, Up
    // Expected: Elev0 assigned (on the way)
}
```

### 8.3 Stress Tests

```cpp
TEST(StressTest, HighTraffic) {
    // 100 random hall calls in 10 seconds
    // Verify: no crashes, no deadlocks, all processed
}

TEST(StressTest, ConcurrentRequests) {
    // 4 threads, 25 requests each
    // Verify: thread-safe, no data races
}
```

---

## 9. Error Handling

| Scenario | Handling |
|----------|----------|
| Invalid floor | Log warning, return early |
| Invalid elevator ID | Log error, return |
| Hall call at boundary | Validate direction (no Down at floor 1) |
| Capacity exceeded | Reject boarding |
| Queue shutdown | Return `std::nullopt` |

---

## 10. CLI Commands

```
hall <floor> <u|d>   - Register hall call
car <elev> <floor>   - Register car call  
status               - Print all elevator states
help                 - Show commands
quit                 - Exit simulation
```

---

## 11. Logging Format

```
[T0001] [HALL CALL] floor=5 dir=Up
[T0001] [ASSIGNMENT] elevator=1 -> floor=5 dir=Up
[T0003] [ELEVATOR 1] floor=2 state=Moving dir=Up
[T0007] [ELEVATOR 1] floor=5 state=DoorsOpening dir=Up
[T0010] [EVENT] DoorsClosed elevator=1
```

---

## 12. Class Diagram

```
┌─────────────────┐       ┌──────────────────┐
│   IScheduler    │◄──────│ MasterController │
│   (interface)   │       │                  │
└────────┬────────┘       │ - assignments_   │
         │                │ - selectElevator │
         │                │ - calculateCost  │
         │                └──────────────────┘
         │
┌────────┴────────┐
│SimulationEngine │
│                 │───────┐
│ - building_     │       │
│ - scheduler_    │       │
│ - eventQueue_   │       │
└─────────────────┘       │
                          │
              ┌───────────┴───────────┐
              │                       │
      ┌───────▼───────┐       ┌───────▼───────┐
      │   Building    │       │  EventQueue   │
      │               │       │               │
      │ - floors_     │       │ - queue_      │
      │ - elevators_  │       │ - mutex_      │
      └───────────────┘       │ - cv_         │
              │               └───────────────┘
      ┌───────┴───────┐
      │               │
┌─────▼─────┐  ┌──────▼──────┐
│   Floor   │  │  Elevator   │
│           │  │             │
│ - upBtn   │  │ - carCalls_ │
│ - downBtn │  │ - state_    │
└───────────┘  │ - direction_│
               └─────────────┘
```
