#ifndef DOMAIN_HPP
#define DOMAIN_HPP

#include "Types.hpp"
#include <vector>
#include <set>
#include <memory>
#include <mutex>
#include <optional>

// ======================= Floor =======================

/**
 * Represents a single floor with up/down call buttons.
 */
class Floor {
private:
    int floorNumber_;
    bool upButtonPressed_ = false;
    bool downButtonPressed_ = false;

public:
    explicit Floor(int number);

    // Button operations
    void pressUpButton();
    void pressDownButton();
    void clearUpButton();
    void clearDownButton();

    // Queries
    bool isUpPressed() const;
    bool isDownPressed() const;
    int getNumber() const;
};

// ======================= Elevator =======================

/**
 * Represents an elevator car with state, position, and pending calls.
 * Thread-safe: all public methods are synchronized.
 */
class Elevator {
private:
    int id_;
    int currentFloor_;
    Direction direction_ = Direction::Idle;
    ElevatorState state_ = ElevatorState::Idle;
    std::set<int> carCalls_;      // Destination floors (sorted, unique)
    int passengerCount_ = 0;
    int capacity_;
    int ticksRemaining_ = 0;      // Countdown for current operation

    mutable std::mutex mutex_;

public:
    Elevator(int id, int capacity, int startFloor = 1);

    // ---- Thread-safe Getters ----
    int getId() const;
    int getCurrentFloor() const;
    Direction getDirection() const;
    ElevatorState getState() const;
    int getPassengerCount() const;
    int getCapacity() const;
    std::set<int> getCarCalls() const;
    int getTicksRemaining() const;

    // ---- Car Call Management ----
    void addCarCall(int floor);
    void removeCarCall(int floor);
    bool hasCarCallAt(int floor) const;
    bool hasAnyCarCalls() const;

    // ---- State Transitions ----
    void startMoving(Direction dir, int ticksToArrive);
    void decrementTick();
    void arriveAtFloor(int floor);
    void openDoors(int ticksToOpen);
    void setDoorsOpen(int ticksOpen);
    void closeDoors(int ticksToClose);
    void setIdle();

    // ---- Query Helpers ----
    bool hasCallsAbove() const;
    bool hasCallsBelow() const;
    std::optional<int> getNextCarCallInDirection() const;

    // ---- Scheduling Helper ----
    int costToServe(int floor, Direction dir, int numFloors) const;

    // ---- Passenger Management ----
    bool canBoard() const;
    void boardPassenger();
    void alightPassenger();
};

// ======================= Building =======================

/**
 * Represents the building containing floors and elevators.
 * Thread-safe for hall call operations.
 */
class Building {
private:
    std::vector<Floor> floors_;
    std::vector<std::unique_ptr<Elevator>> elevators_;
    Config config_;
    mutable std::mutex mutex_;

public:
    explicit Building(const Config& config);

    // ---- Accessors ----
    int getNumFloors() const;
    int getNumElevators() const;
    const Config& getConfig() const;

    // ---- Elevator Access ----
    Elevator& getElevator(int id);
    const Elevator& getElevator(int id) const;

    // ---- Floor Access ----
    Floor& getFloor(int number);
    const Floor& getFloor(int number) const;

    // ---- Hall Call Management ----
    void registerHallCall(int floor, Direction dir);
    void clearHallCall(int floor, Direction dir);
    bool hasHallCall(int floor, Direction dir) const;

    // ---- Get All Pending Hall Calls ----
    std::vector<std::pair<int, Direction>> getAllHallCalls() const;

    // ---- Validation ----
    bool isValidFloor(int floor) const;
    bool isValidElevator(int id) const;
};

#endif // DOMAIN_HPP
