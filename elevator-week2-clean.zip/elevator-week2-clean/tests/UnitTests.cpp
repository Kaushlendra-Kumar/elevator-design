#include <gtest/gtest.h>
#include "Types.hpp"
#include "Domain.hpp"
#include "EventQueue.hpp"
#include "Scheduler.hpp"
#include "Simulation.hpp"

// ======================= Floor Tests =======================

TEST(FloorTest, InitialState) {
    Floor floor(5);
    EXPECT_EQ(floor.getNumber(), 5);
    EXPECT_FALSE(floor.isUpPressed());
    EXPECT_FALSE(floor.isDownPressed());
}

TEST(FloorTest, PressUpButton) {
    Floor floor(3);
    floor.pressUpButton();
    EXPECT_TRUE(floor.isUpPressed());
    EXPECT_FALSE(floor.isDownPressed());
}

TEST(FloorTest, PressDownButton) {
    Floor floor(3);
    floor.pressDownButton();
    EXPECT_FALSE(floor.isUpPressed());
    EXPECT_TRUE(floor.isDownPressed());
}

TEST(FloorTest, PressBothButtons) {
    Floor floor(3);
    floor.pressUpButton();
    floor.pressDownButton();
    EXPECT_TRUE(floor.isUpPressed());
    EXPECT_TRUE(floor.isDownPressed());
}

TEST(FloorTest, ClearButtons) {
    Floor floor(3);
    floor.pressUpButton();
    floor.pressDownButton();
    
    floor.clearUpButton();
    EXPECT_FALSE(floor.isUpPressed());
    EXPECT_TRUE(floor.isDownPressed());
    
    floor.clearDownButton();
    EXPECT_FALSE(floor.isDownPressed());
}

// ======================= Elevator Tests =======================

TEST(ElevatorTest, InitialState) {
    Elevator elev(0, 6, 1);
    
    EXPECT_EQ(elev.getId(), 0);
    EXPECT_EQ(elev.getCurrentFloor(), 1);
    EXPECT_EQ(elev.getDirection(), Direction::Idle);
    EXPECT_EQ(elev.getState(), ElevatorState::Idle);
    EXPECT_EQ(elev.getPassengerCount(), 0);
    EXPECT_EQ(elev.getCapacity(), 6);
    EXPECT_FALSE(elev.hasAnyCarCalls());
}

TEST(ElevatorTest, AddCarCall) {
    Elevator elev(0, 6, 1);
    
    elev.addCarCall(5);
    EXPECT_TRUE(elev.hasAnyCarCalls());
    EXPECT_TRUE(elev.hasCarCallAt(5));
    EXPECT_FALSE(elev.hasCarCallAt(3));
}

TEST(ElevatorTest, CarCallsSorted) {
    Elevator elev(0, 6, 1);
    
    elev.addCarCall(8);
    elev.addCarCall(3);
    elev.addCarCall(5);
    
    auto calls = elev.getCarCalls();
    EXPECT_EQ(calls.size(), 3);
    
    auto it = calls.begin();
    EXPECT_EQ(*it++, 3);
    EXPECT_EQ(*it++, 5);
    EXPECT_EQ(*it++, 8);
}

TEST(ElevatorTest, RemoveCarCall) {
    Elevator elev(0, 6, 1);
    
    elev.addCarCall(5);
    elev.addCarCall(8);
    
    elev.removeCarCall(5);
    EXPECT_FALSE(elev.hasCarCallAt(5));
    EXPECT_TRUE(elev.hasCarCallAt(8));
}

TEST(ElevatorTest, StateTransitionMoving) {
    Elevator elev(0, 6, 1);
    
    elev.startMoving(Direction::Up, 2);
    EXPECT_EQ(elev.getState(), ElevatorState::Moving);
    EXPECT_EQ(elev.getDirection(), Direction::Up);
    EXPECT_EQ(elev.getTicksRemaining(), 2);
}

TEST(ElevatorTest, DecrementTick) {
    Elevator elev(0, 6, 1);
    elev.startMoving(Direction::Up, 3);
    
    elev.decrementTick();
    EXPECT_EQ(elev.getTicksRemaining(), 2);
    
    elev.decrementTick();
    elev.decrementTick();
    EXPECT_EQ(elev.getTicksRemaining(), 0);
    
    // Should not go negative
    elev.decrementTick();
    EXPECT_EQ(elev.getTicksRemaining(), 0);
}

TEST(ElevatorTest, ArriveAtFloor) {
    Elevator elev(0, 6, 1);
    elev.startMoving(Direction::Up, 2);
    
    elev.arriveAtFloor(2);
    EXPECT_EQ(elev.getCurrentFloor(), 2);
    EXPECT_EQ(elev.getState(), ElevatorState::DoorsOpening);
}

TEST(ElevatorTest, SetIdle) {
    Elevator elev(0, 6, 1);
    elev.startMoving(Direction::Up, 2);
    
    elev.setIdle();
    EXPECT_EQ(elev.getState(), ElevatorState::Idle);
    EXPECT_EQ(elev.getDirection(), Direction::Idle);
}

TEST(ElevatorTest, HasCallsAboveAndBelow) {
    Elevator elev(0, 6, 5);  // Start at floor 5
    elev.startMoving(Direction::Up, 1);
    
    elev.addCarCall(8);
    elev.addCarCall(3);
    
    EXPECT_TRUE(elev.hasCallsAbove());
    EXPECT_TRUE(elev.hasCallsBelow());
}

TEST(ElevatorTest, PassengerCapacity) {
    Elevator elev(0, 2, 1);  // Capacity of 2
    
    EXPECT_TRUE(elev.canBoard());
    elev.boardPassenger();
    EXPECT_TRUE(elev.canBoard());
    elev.boardPassenger();
    EXPECT_FALSE(elev.canBoard());
    EXPECT_EQ(elev.getPassengerCount(), 2);
    
    elev.alightPassenger();
    EXPECT_TRUE(elev.canBoard());
}

TEST(ElevatorTest, CostToServeIdle) {
    Elevator elev(0, 6, 5);  // At floor 5, idle
    
    // Idle elevator: cost = distance
    EXPECT_EQ(elev.costToServe(3, Direction::Up, 10), 2);
    EXPECT_EQ(elev.costToServe(8, Direction::Down, 10), 3);
}

TEST(ElevatorTest, CostToServeOnTheWay) {
    Elevator elev(0, 6, 3);
    elev.startMoving(Direction::Up, 2);
    
    // Moving up, request is above: on the way, low cost
    int cost = elev.costToServe(5, Direction::Up, 10);
    EXPECT_EQ(cost, 2);  // Just distance
}

TEST(ElevatorTest, CostToServeWrongDirection) {
    Elevator elev(0, 6, 3);
    elev.startMoving(Direction::Up, 2);
    
    // Moving up, request is below: needs to reverse, high cost
    int cost = elev.costToServe(1, Direction::Down, 10);
    EXPECT_GT(cost, 10);  // Distance + penalty
}

// ======================= Building Tests =======================

TEST(BuildingTest, Initialization) {
    Config config;
    config.numFloors = 10;
    config.numElevators = 3;
    
    Building building(config);
    
    EXPECT_EQ(building.getNumFloors(), 10);
    EXPECT_EQ(building.getNumElevators(), 3);
}

TEST(BuildingTest, ValidFloor) {
    Config config;
    config.numFloors = 5;
    Building building(config);
    
    EXPECT_TRUE(building.isValidFloor(1));
    EXPECT_TRUE(building.isValidFloor(5));
    EXPECT_FALSE(building.isValidFloor(0));
    EXPECT_FALSE(building.isValidFloor(6));
}

TEST(BuildingTest, ValidElevator) {
    Config config;
    config.numElevators = 2;
    Building building(config);
    
    EXPECT_TRUE(building.isValidElevator(0));
    EXPECT_TRUE(building.isValidElevator(1));
    EXPECT_FALSE(building.isValidElevator(2));
    EXPECT_FALSE(building.isValidElevator(-1));
}

TEST(BuildingTest, HallCallManagement) {
    Config config;
    config.numFloors = 10;
    Building building(config);
    
    EXPECT_FALSE(building.hasHallCall(5, Direction::Up));
    
    building.registerHallCall(5, Direction::Up);
    EXPECT_TRUE(building.hasHallCall(5, Direction::Up));
    EXPECT_FALSE(building.hasHallCall(5, Direction::Down));
    
    building.clearHallCall(5, Direction::Up);
    EXPECT_FALSE(building.hasHallCall(5, Direction::Up));
}

TEST(BuildingTest, GetAllHallCalls) {
    Config config;
    config.numFloors = 10;
    Building building(config);
    
    building.registerHallCall(3, Direction::Up);
    building.registerHallCall(7, Direction::Down);
    building.registerHallCall(5, Direction::Up);
    
    auto calls = building.getAllHallCalls();
    EXPECT_EQ(calls.size(), 3);
}

// ======================= EventQueue Tests =======================

TEST(EventQueueTest, PushAndPop) {
    EventQueue<int> queue;
    
    queue.push(42);
    EXPECT_FALSE(queue.empty());
    
    auto result = queue.tryPop();
    EXPECT_TRUE(result.has_value());
    EXPECT_EQ(*result, 42);
    EXPECT_TRUE(queue.empty());
}

TEST(EventQueueTest, FIFO) {
    EventQueue<int> queue;
    
    queue.push(1);
    queue.push(2);
    queue.push(3);
    
    EXPECT_EQ(queue.tryPop().value(), 1);
    EXPECT_EQ(queue.tryPop().value(), 2);
    EXPECT_EQ(queue.tryPop().value(), 3);
}

TEST(EventQueueTest, TryPopEmpty) {
    EventQueue<int> queue;
    
    auto result = queue.tryPop();
    EXPECT_FALSE(result.has_value());
}

TEST(EventQueueTest, Shutdown) {
    EventQueue<int> queue;
    queue.shutdown();
    
    EXPECT_TRUE(queue.isShutdown());
}

TEST(EventQueueTest, Size) {
    EventQueue<int> queue;
    
    EXPECT_EQ(queue.size(), 0);
    queue.push(1);
    queue.push(2);
    EXPECT_EQ(queue.size(), 2);
}

// ======================= Master Controller Tests =======================

TEST(MasterControllerTest, HandleHallCall) {
    Config config;
    config.numFloors = 10;
    config.numElevators = 3;
    
    Building building(config);
    EventQueue<Event> queue;
    MasterController controller(building, queue);
    
    controller.handleHallCall(5, Direction::Up);
    
    // Hall call should be registered
    EXPECT_TRUE(building.hasHallCall(5, Direction::Up));
    
    // Assignment should exist
    EXPECT_TRUE(controller.hasAssignment(5, Direction::Up));
}

TEST(MasterControllerTest, NoDuplicateAssignment) {
    Config config;
    config.numFloors = 10;
    config.numElevators = 3;
    
    Building building(config);
    EventQueue<Event> queue;
    MasterController controller(building, queue);
    
    controller.handleHallCall(5, Direction::Up);
    size_t countBefore = controller.getAssignmentCount();
    
    // Same hall call again
    controller.handleHallCall(5, Direction::Up);
    size_t countAfter = controller.getAssignmentCount();
    
    // Should not create duplicate
    EXPECT_EQ(countBefore, countAfter);
}

TEST(MasterControllerTest, HandleCarCall) {
    Config config;
    config.numFloors = 10;
    config.numElevators = 1;
    
    Building building(config);
    EventQueue<Event> queue;
    MasterController controller(building, queue);
    
    controller.handleCarCall(0, 8);
    
    EXPECT_TRUE(building.getElevator(0).hasCarCallAt(8));
}

TEST(MasterControllerTest, AssignsNearestIdleElevator) {
    Config config;
    config.numFloors = 10;
    config.numElevators = 2;
    
    Building building(config);
    
    // Move elevator 1 to floor 5 manually (simulate)
    // Both start at floor 1, so first call should go to elevator 0
    
    EventQueue<Event> queue;
    MasterController controller(building, queue);
    
    controller.handleHallCall(3, Direction::Up);
    
    // Should be assigned to one of the elevators
    auto assigned = controller.getAssignedElevator(3, Direction::Up);
    EXPECT_TRUE(assigned.has_value());
}

TEST(MasterControllerTest, ClearAssignmentOnArrival) {
    Config config;
    config.numFloors = 10;
    config.numElevators = 1;
    
    Building building(config);
    EventQueue<Event> queue;
    MasterController controller(building, queue);
    
    controller.handleHallCall(3, Direction::Up);
    EXPECT_TRUE(controller.hasAssignment(3, Direction::Up));
    
    // Simulate elevator arriving
    building.getElevator(0).startMoving(Direction::Up, 1);
    building.getElevator(0).arriveAtFloor(3);
    
    controller.onElevatorArrived(0, 3);
    
    // Assignment should be cleared
    EXPECT_FALSE(controller.hasAssignment(3, Direction::Up));
}

// ======================= Integration Tests =======================

TEST(IntegrationTest, BasicSimulation) {
    Config config;
    config.numFloors = 5;
    config.numElevators = 1;
    config.tickDurationMs = 10;  // Fast for testing
    
    SimulationEngine engine(config);
    
    engine.requestHallCall(3, Direction::Up);
    
    engine.start();
    std::this_thread::sleep_for(std::chrono::milliseconds(100));
    engine.stop();
    
    // If we got here without crash, basic functionality works
    SUCCEED();
}

TEST(IntegrationTest, MultipleElevators) {
    Config config;
    config.numFloors = 10;
    config.numElevators = 3;
    config.tickDurationMs = 10;
    
    SimulationEngine engine(config);
    
    engine.requestHallCall(5, Direction::Up);
    engine.requestHallCall(8, Direction::Down);
    engine.requestCarCall(1, 10);
    
    engine.start();
    std::this_thread::sleep_for(std::chrono::milliseconds(200));
    engine.stop();
    
    SUCCEED();
}

// ======================= Main =======================

int main(int argc, char** argv) {
    testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
