# Elevator Simulation System
## Week 2: Master Controller Architecture

A realistic elevator simulation for modeling building elevator operations with centralized scheduling.

---

## Overview

This simulation implements a **Master Controller** (centralized scheduler) that:
- Receives all hall calls and car calls
- Assigns requests to optimal elevators using **LOOK algorithm**
- Ensures no duplicate service for same request
- Manages multiple elevators efficiently

---

## Features

| Feature | Status |
|---------|--------|
| Configurable floors (1-12) | ✅ |
| Configurable elevators (1-3) | ✅ |
| Configurable capacity | ✅ |
| Hall calls (Up/Down) | ✅ |
| Car calls | ✅ |
| LOOK scheduling algorithm | ✅ |
| Thread-safe design | ✅ |
| Event-driven simulation | ✅ |
| Unit tests (GoogleTest) | ✅ |
| Stress tests | ✅ |

---

## Project Structure

```
elevator-sim/
├── CMakeLists.txt
├── README.md
├── docs/
│   ├── HLD.md              # High-Level Design
│   └── LLD.md              # Low-Level Design
├── include/
│   ├── Types.hpp           # Enums, Config, Event
│   ├── EventQueue.hpp      # Thread-safe queue
│   ├── Domain.hpp          # Elevator, Floor, Building
│   ├── Scheduler.hpp       # IScheduler + MasterController
│   └── Simulation.hpp      # Engine, Logger, CLI
├── src/
│   ├── main.cpp
│   ├── Domain.cpp
│   ├── Scheduler.cpp
│   └── Simulation.cpp
└── tests/
    ├── UnitTests.cpp
    └── StressTests.cpp
```

---

## Building

### Prerequisites
- C++17 compiler (GCC 9+ or Clang 10+)
- CMake 3.16+
- Git

### Windows (MinGW)
```powershell
cd elevator-sim
cmake -G "MinGW Makefiles" -B build
cmake --build build
# Or: mingw32-make -C build
```

### Linux/macOS
```bash
cd elevator-sim
cmake -B build
cmake --build build -j4
```

---

## Running

### Basic Usage
```bash
./build/elevator
```

### With Options
```bash
./build/elevator -f 12 -e 3        # 12 floors, 3 elevators
./build/elevator -t 100            # Fast simulation (100ms ticks)
./build/elevator -c 10             # Capacity of 10
```

### Command-Line Options
| Option | Description | Default |
|--------|-------------|---------|
| `-f, --floors` | Number of floors (1-12) | 10 |
| `-e, --elevators` | Number of elevators (1-3) | 3 |
| `-c, --capacity` | Car capacity (1-10) | 6 |
| `-t, --tick` | Tick duration in ms | 500 |
| `-h, --help` | Show help | - |

### Interactive Commands
```
hall 5 u        # Hall call: floor 5, going up
hall 8 d        # Hall call: floor 8, going down
car 0 10        # Car call: elevator 0 to floor 10
status          # Show current state
help            # Show commands
quit            # Exit
```

---

## Testing

### Run Unit Tests
```bash
./build/unit_tests
```

### Run Stress Tests
```bash
./build/stress_tests
```

### Run Specific Test
```bash
./build/unit_tests --gtest_filter="MasterControllerTest.*"
```

### With Sanitizers
```bash
# AddressSanitizer (memory errors)
cmake -B build -DENABLE_ASAN=ON
cmake --build build
./build/unit_tests

# ThreadSanitizer (data races)
cmake -B build -DENABLE_TSAN=ON
cmake --build build
./build/unit_tests
```

---

## Architecture

### Master Controller Algorithm

1. **Request Assignment**: When hall call arrives, calculate cost for each elevator
2. **Cost Calculation**: 
   - Idle elevator: `cost = distance`
   - Moving toward request: `cost = distance`
   - Moving away: `cost = distance + 2 × numFloors`
3. **Dispatch**: Assign to lowest-cost elevator
4. **No Duplicates**: Track assignments in map, skip if already assigned

### Threading Model
```
Main Thread (CLI)
       │
       └──► Simulation Loop Thread
               - Process ticks
               - Update elevator states
               - Handle events
```

### Synchronization
- `EventQueue`: mutex + condition_variable
- `Building`: mutex for hall call state
- `Elevator`: mutex for state changes
- `MasterController`: mutex for assignments

---

## Key C++ Concepts Used

| Concept | Usage |
|---------|-------|
| `std::thread` | Simulation loop |
| `std::mutex` | Protect shared state |
| `std::condition_variable` | Event queue blocking |
| `std::atomic` | Running flag, tick counter |
| `std::unique_ptr` | Elevator ownership |
| `std::set` | Sorted car calls |
| `std::map` | Assignment tracking |
| `std::optional` | Nullable return values |

---

## Quality Metrics

| Metric | Target | Implementation |
|--------|--------|----------------|
| Build warnings | Zero | `-Wall -Wextra -Werror` |
| Memory leaks | Zero | Smart pointers, RAII |
| Data races | Zero | Mutex protection |
| Test coverage | >60% | Unit + Stress tests |
| Deadlock | None | Consistent lock order |

---

## Design for Extensibility

The `IScheduler` interface allows adding new scheduling strategies:

```cpp
class IScheduler {
    virtual void handleHallCall(...) = 0;
    // ...
};

class MasterController : public IScheduler { ... };
```

---

## Author

Master Controller Architecture Implementation
