# Elevator Simulation - High Level Design
## Week 2: Master Controller Architecture

---

## 1. Problem Statement

Build a realistic elevator simulation for a building with:
- **1-12 floors** (configurable)
- **1-3 elevator cars** (configurable)
- **Master Controller Architecture** (centralized scheduling)

Purpose: Validate scheduling logic, concurrency correctness, and modular C++ design.

---

## 2. System Architecture

```
┌─────────────────────────────────────────────────────┐
│                   CLI / Main                        │
│          (Configuration, Commands, Display)         │
├─────────────────────────────────────────────────────┤
│                Simulation Engine                    │
│        (Clock, Event Loop, Thread Management)       │
├─────────────────────────────────────────────────────┤
│               Master Controller                     │
│    (Central Scheduler - LOOK Algorithm)             │
│    - Receives ALL requests                          │
│    - Assigns elevators optimally                    │
│    - Tracks assignments to prevent duplicates       │
├─────────────────────────────────────────────────────┤
│                 Domain Layer                        │
│        (Building, Elevators, Floors, Requests)      │
└─────────────────────────────────────────────────────┘
```

---

## 3. Master Controller Model

### 3.1 Core Concept
The Master Controller acts as a **central brain** that:
- Receives all hall calls and car calls
- Decides which elevator serves which request
- Ensures **no duplicate assignments**
- Optimizes for **minimum wait time**

### 3.2 Why Centralized?
| Advantage | Description |
|-----------|-------------|
| **Global View** | Sees all elevators and requests simultaneously |
| **Optimal Assignment** | Can pick truly best elevator |
| **Simple Coordination** | No need for elevator-to-elevator communication |
| **Easy to Debug** | Single decision point |

### 3.3 LOOK Scheduling Algorithm
```
LOOK Algorithm (Elevator Scheduling):
1. Continue in current direction while requests exist ahead
2. When no more requests ahead, reverse direction
3. If no requests in either direction, go idle

Cost Calculation:
- Base cost = |elevator_floor - request_floor|
- Penalty if elevator moving away = +2 × num_floors
- Idle elevator = base cost only (preferred)
```

---

## 4. Component Overview

| Component | Responsibility |
|-----------|----------------|
| **Building** | Holds floors, elevators, hall call state |
| **Elevator** | Position, direction, state, car calls, passengers |
| **Floor** | Up/Down button state |
| **MasterController** | Central scheduling, assignment tracking |
| **SimulationEngine** | Time management, event dispatch, threads |
| **EventQueue** | Thread-safe event passing |
| **Logger** | Telemetry and debugging output |

---

## 5. Threading Model

```
┌─────────────────────────────────────────┐
│              Main Thread                │
│         (CLI input processing)          │
└─────────────────┬───────────────────────┘
                  │
                  │ spawns
                  ▼
┌─────────────────────────────────────────┐
│         Simulation Loop Thread          │
│  - Processes ticks                      │
│  - Updates elevator positions           │
│  - Triggers state transitions           │
│  - Calls MasterController.tick()        │
└─────────────────────────────────────────┘

Synchronization Points:
┌──────────────────┬──────────────────────┐
│ Resource         │ Protection           │
├──────────────────┼──────────────────────┤
│ EventQueue       │ mutex + cond_var     │
│ Building state   │ mutex                │
│ Elevator state   │ mutex (per elevator) │
│ Assignments map  │ mutex                │
└──────────────────┴──────────────────────┘
```

---

## 6. Request Flow

### 6.1 Hall Call Flow
```
User: "hall 5 u"
       │
       ▼
┌──────────────────┐
│ SimulationEngine │ validates input
└────────┬─────────┘
         │ push HallCallEvent
         ▼
┌──────────────────┐
│   EventQueue     │ thread-safe
└────────┬─────────┘
         │ pop event
         ▼
┌──────────────────┐
│ MasterController │
│  1. Register in Building
│  2. Calculate cost for each elevator
│  3. Assign to best elevator
│  4. Store in assignments map
└────────┬─────────┘
         │
         ▼
┌──────────────────┐
│    Elevator      │ starts moving
└──────────────────┘
```

### 6.2 Car Call Flow
```
User: "car 0 8"
       │
       ▼
┌──────────────────┐
│ MasterController │
│  1. Add to elevator's carCalls set
│  2. Dispatch elevator if idle
└──────────────────┘
```

---

## 7. State Machine - Elevator

```
         ┌─────────────────────────────────┐
         │                                 │
         ▼                                 │
    ┌─────────┐                            │
    │  IDLE   │◄───────────────────────────┤
    └────┬────┘                            │
         │ assigned request                │
         ▼                                 │
    ┌─────────┐                            │
    │ MOVING  │ (decrement ticks each tick)│
    └────┬────┘                            │
         │ ticks == 0                      │
         ▼                                 │
    ┌─────────────┐                        │
    │DOORS_OPENING│                        │
    └────┬────────┘                        │
         │ ticks == 0                      │
         ▼                                 │
    ┌─────────────┐                        │
    │ DOORS_OPEN  │ (passengers board)     │
    └────┬────────┘                        │
         │ ticks == 0                      │
         ▼                                 │
    ┌─────────────┐                        │
    │DOORS_CLOSING│                        │
    └────┬────────┘                        │
         │                                 │
         ├── more requests? ──► MOVING     │
         │                                 │
         └── no requests? ─────────────────┘
```

---

## 8. Key Design Decisions

| Decision | Choice | Rationale |
|----------|--------|-----------|
| Scheduling | LOOK Algorithm | Fair, efficient, industry standard |
| Time Model | Tick-based | Deterministic, testable |
| Communication | Event Queue | Decoupled, thread-safe |
| Memory | Smart Pointers | RAII, no leaks |
| Assignment Tracking | std::map | O(log n) lookup, ordered |

---

## 9. Configuration

| Parameter | Range | Default | CLI Flag |
|-----------|-------|---------|----------|
| Floors | 1-12 | 10 | `-f` |
| Elevators | 1-3 | 3 | `-e` |
| Capacity | 1-10 | 6 | `-c` |
| Tick Duration | 100-2000ms | 500ms | `-t` |

---

## 10. Quality Requirements

| Requirement | How Achieved |
|-------------|--------------|
| **No Deadlocks** | Single mutex per resource, consistent lock order |
| **No Data Races** | All shared state mutex-protected |
| **No Memory Leaks** | Smart pointers, RAII |
| **No Request Loss** | Assignment map tracks all requests |
| **Testability** | Dependency injection, mockable interfaces |

---

## 11. Technology Stack

| Aspect | Choice |
|--------|--------|
| Language | C++17 |
| Build | CMake 3.16+ |
| Threading | std::thread, std::mutex, std::condition_variable |
| Testing | GoogleTest |
| Containers | std::vector, std::set, std::map, std::queue |

---

## 12. Design for Extensibility

The `IScheduler` interface allows adding new scheduling strategies:
```cpp
class IScheduler {
    virtual void handleHallCall(...) = 0;
    virtual void handleCarCall(...) = 0;
    // ...
};

class MasterController : public IScheduler { ... };
```
