#ifndef SCHEDULER_HPP
#define SCHEDULER_HPP

#include "Types.hpp"
#include "Domain.hpp"
#include "EventQueue.hpp"
#include <map>
#include <mutex>
#include <memory>

// ======================= Scheduler Interface =======================

/**
 * Interface for elevator scheduling strategies.
 * Allows for different scheduling algorithms to be implemented.
 */
class IScheduler {
public:
    virtual ~IScheduler() = default;

    // Handle incoming requests
    virtual void handleHallCall(int floor, Direction dir) = 0;
    virtual void handleCarCall(int elevatorId, int floor) = 0;

    // Elevator state change notifications
    virtual void onElevatorArrived(int elevatorId, int floor) = 0;
    virtual void onDoorsOpened(int elevatorId, int floor) = 0;
    virtual void onDoorsClosed(int elevatorId) = 0;

    // Called each simulation tick
    virtual void tick() = 0;

    // Identifier for logging
    virtual std::string getName() const = 0;
};

// ======================= Master Controller =======================

/**
 * Centralized elevator scheduler using LOOK algorithm.
 * 
 * Responsibilities:
 * - Receive all hall calls and car calls
 * - Assign hall calls to optimal elevator
 * - Track assignments to prevent duplicate service
 * - Dispatch idle elevators
 * 
 * Algorithm:
 * - Cost = distance + penalty if not on-the-way
 * - Idle elevators preferred (lowest cost)
 * - Moving elevator "on the way" gets no penalty
 */
class MasterController : public IScheduler {
private:
    Building& building_;
    EventQueue<Event>& eventQueue_;

    // Assignment tracking: (floor, direction) -> assigned elevator ID
    // Ensures each hall call assigned exactly once
    std::map<std::pair<int, Direction>, int> assignments_;
    mutable std::mutex mutex_;

public:
    MasterController(Building& building, EventQueue<Event>& queue);

    // ---- IScheduler Implementation ----
    void handleHallCall(int floor, Direction dir) override;
    void handleCarCall(int elevatorId, int floor) override;
    void onElevatorArrived(int elevatorId, int floor) override;
    void onDoorsOpened(int elevatorId, int floor) override;
    void onDoorsClosed(int elevatorId) override;
    void tick() override;
    std::string getName() const override { return "MasterController"; }

    // ---- Testing/Debug Access ----
    size_t getAssignmentCount() const;
    bool hasAssignment(int floor, Direction dir) const;
    std::optional<int> getAssignedElevator(int floor, Direction dir) const;

private:
    /**
     * Select best elevator for a hall call using cost calculation.
     * Returns elevator ID or -1 if none available.
     */
    int selectElevator(int floor, Direction dir);

    /**
     * Calculate cost for elevator to serve a request.
     * Lower cost = better choice.
     */
    int calculateCost(const Elevator& elev, int floor, Direction dir);

    /**
     * Dispatch elevator to its next destination.
     * Called when elevator becomes idle or finishes a stop.
     */
    void dispatchElevator(int elevatorId);

    /**
     * Check if elevator should stop at given floor.
     */
    bool shouldStopAtFloor(int elevatorId, int floor);

    /**
     * Get assignment for floor/direction if exists.
     */
    std::optional<int> getAssignment(int floor, Direction dir);

    /**
     * Clear assignment when request is served.
     */
    void clearAssignment(int floor, Direction dir);

    /**
     * Get all destinations for an elevator (car calls + assigned hall calls).
     */
    std::set<int> getAllDestinations(int elevatorId);
};

// ======================= Factory Function =======================

/**
 * Create scheduler instance (Master Controller).
 */
std::unique_ptr<IScheduler> createScheduler(
    Building& building,
    EventQueue<Event>& queue
);

#endif // SCHEDULER_HPP
