#ifndef EVENT_QUEUE_HPP
#define EVENT_QUEUE_HPP

#include <queue>
#include <mutex>
#include <condition_variable>
#include <optional>
#include <atomic>

/**
 * Thread-safe event queue using mutex and condition variable.
 * Supports blocking wait and graceful shutdown.
 */
template<typename T>
class EventQueue {
private:
    std::queue<T> queue_;
    mutable std::mutex mutex_;
    std::condition_variable cv_;
    std::atomic<bool> shutdown_{false};

public:
    EventQueue() = default;
    
    // Non-copyable, non-movable (due to mutex)
    EventQueue(const EventQueue&) = delete;
    EventQueue& operator=(const EventQueue&) = delete;

    /**
     * Add event to queue and notify one waiting thread.
     * Thread-safe.
     */
    void push(T event) {
        {
            std::lock_guard<std::mutex> lock(mutex_);
            queue_.push(std::move(event));
        }
        cv_.notify_one();
    }

    /**
     * Wait for and retrieve next event.
     * Blocks until event available or shutdown signaled.
     * Returns std::nullopt on shutdown with empty queue.
     */
    std::optional<T> pop() {
        std::unique_lock<std::mutex> lock(mutex_);
        cv_.wait(lock, [this] { 
            return !queue_.empty() || shutdown_.load(); 
        });

        if (shutdown_.load() && queue_.empty()) {
            return std::nullopt;
        }

        T event = std::move(queue_.front());
        queue_.pop();
        return event;
    }

    /**
     * Try to retrieve event without blocking.
     * Returns std::nullopt if queue is empty.
     */
    std::optional<T> tryPop() {
        std::lock_guard<std::mutex> lock(mutex_);
        if (queue_.empty()) {
            return std::nullopt;
        }
        T event = std::move(queue_.front());
        queue_.pop();
        return event;
    }

    /**
     * Signal shutdown - unblocks all waiting threads.
     */
    void shutdown() {
        shutdown_.store(true);
        cv_.notify_all();
    }

    /**
     * Reset queue for reuse (clears shutdown flag and queue).
     */
    void reset() {
        std::lock_guard<std::mutex> lock(mutex_);
        shutdown_.store(false);
        std::queue<T> empty;
        std::swap(queue_, empty);
    }

    /**
     * Check if queue is empty.
     */
    bool empty() const {
        std::lock_guard<std::mutex> lock(mutex_);
        return queue_.empty();
    }

    /**
     * Get current queue size.
     */
    size_t size() const {
        std::lock_guard<std::mutex> lock(mutex_);
        return queue_.size();
    }

    /**
     * Check if shutdown was signaled.
     */
    bool isShutdown() const {
        return shutdown_.load();
    }
};

#endif // EVENT_QUEUE_HPP
